#This program takes inputs for files of sales data displays that
#data and then sorts it.

#Author: Devin Gilmore

#Define funcion to get the sales person IDs.
salesinfo = []
listofsales = []
listofids = []
def getIDs(filename):
    sales_person_ids = open(filename)
#defining the variables.
    Id = 0
    quarter = 1
#create list for the quarter sales.
    salesid=0
    while salesid != 6:
        for quarter in range(1,5):
            templist = [salesid, quarter, 0.00]
            salesinfo.append(templist)
            quarter += 1
        salesid += 1
#create list for the salesperson IDS.
    while Id != (""):
        Id = sales_person_ids.readline()
        Id = Id.rstrip("\n")
        if Id == (""):
            sales_person_ids.close()
            return listofids
        listofids.append(Id)
#Define function to get salesdata.
def process_sales_data(filename, id_list, sales_data):
#create list of of the sales data and put in two dimentional list.
    data = open(filename)
    sale = 0
    class BreakIt(Exception): pass
    try:
        while sale != (""):
            sale = data.readline()
            sale = sale.rstrip("\n")
            if sale == (""):
                data.close()
                raise BreakIt
            sale = sale.split(" ")
            listofsales.append(sale)
    except BreakIt:
        pass
#Order the data by ID number and quarter.
    salespersonnumber = 0
#run through the data for every salesperson.
    for salespersonnumber in range(len(id_list)):
#run through the data for every quarter.
        for quarter in range(1,5):
            quartervalue = 0
            datapiece = 0
            id_list.sort()
            qtrend = float(quarter*3)
            qtr = qtrend -3
#search through list until finished and pull out/add up numbers that match critera.
            for datapiece in range(len(listofsales)):
                if listofsales[datapiece][0] == id_list[salespersonnumber]:
                    if float(listofsales[datapiece][1]) > qtr and float(listofsales[datapiece][1]) <= qtrend:
                        quartervalue = quartervalue + float(listofsales[datapiece][2])
#round and determine placement for data.
            quartervalue = round(quartervalue,2)
            placement = (salespersonnumber*4) + (quarter-1)
            salesinfo[placement][2] = quartervalue
#Create the function that will print the report to the screen.
def print_report(id_list,sales_data):
#Set up the begining of the report.    
    print("\n \n \n")
    print("-------------Annual Sales Report-------------")
    print("ID \t\t QT1 \t\t QT2 \t\t QT3 \t\t QT4 \t\t Total")
#print the sales per quarter per ID.
    for numberofids in range(6):
        tempstring = ""
        totalperID = 0
        for numberofdatapoints in range(4):
            numberofdatapoints = numberofdatapoints + (numberofids *4)
            tempstring = tempstring + str(sales_data[numberofdatapoints][2]) + ("\t\t")
            totalperID += sales_data[numberofdatapoints][2]
        totalperID = round(totalperID,2)
        tempstring = tempstring + str(totalperID)
        print(str(id_list[numberofids]) + "\t\t" + tempstring)
#add up the totals for all of the quarters.
    qtsum = 0
    allsalestot = 0
    temptotalstring = "Total\t\t"
    allsales = []
    for qtr in range(1,5):
        tot = 0
        datavalue = 0
        for datavalue in range(len(sales_data)):
            if int(sales_data[datavalue][1]) == qtr:
                tot = tot + float(sales_data[datavalue][2])
                tot = round(tot,2)
        temptotalstring = temptotalstring + str(tot) + ("\t\t")
        allsales.append(tot)
#Add the total sales across all IDs and quarters.
    allsalestot = sum(allsales)
    allsalestot = round(allsalestot,2)
    temptotalstring = temptotalstring + str(allsalestot)
    print(temptotalstring)
    print("\n\n")
#calculate the max sales in any one quarter.
    datavalue = 0
    tempmaxQT = -1
    for datavalue in range(len(sales_data)):
        if float(sales_data[datavalue][2]) > tempmaxQT:
            tempmaxQT = float(sales_data[datavalue][2])
            maxdatavalue = datavalue
    print("Max sales by Salesperson: ID = " + str(id_list[maxdatavalue]) + " Amount = $" + str(tempmaxQT))      
#Calculate the Max sales for each quarter.
    maxperQT = max(allsales)
    qtnum = allsales.index(maxperQT)
    qtnum = int(qtnum)+ 1
    print("Max sales by Quarter: Quarter = " + str(qtnum) +", Amount = $"+str(maxperQT))
#Create the main function that controls the program.
def main():
#Ask user for input oof file names.
    iDfilename = input("Enter file name with the employees:")
    salesInfoFilename = input("Enter file name with the sales data:")
#Run the anaylsis.
    y = getIDs(iDfilename)
    x = process_sales_data(salesInfoFilename,listofids,salesinfo)
    z = print_report(listofids,salesinfo)
#Initiate the main function.

plzwork = main()





