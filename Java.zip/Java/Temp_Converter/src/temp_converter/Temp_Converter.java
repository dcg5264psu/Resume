/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temp_converter;

/**
 *
 * @author Devin Gilmore
 */

//Import used packages
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Color;

public class Temp_Converter extends JFrame {

    private final JLabel labeltop; //label showing the title of GUI 
    private final JButton buttonbottom;//Button tbc
    private final JLabel labeleast; //Label for the result
    private final JLabel labelwest; //Label for fahrenheit label
    private final JTextField centertextbox;//Label for entry box.
    private double fahrenheit;//Create variable to use in equation
    private double celsius;//Create variable to use in equation

    public Temp_Converter() {
        //Set the frame label
        super("Fahrenheit to Celsius Temperature Converter");
        //Create the Layout
        setLayout(new BorderLayout());
        //Define Jlabels
        labeltop = new JLabel("Fahrenheit to Celsius Temperature Converter", JLabel.CENTER);
        labeltop.setForeground (Color.red);
        add(labeltop, BorderLayout.NORTH);
        

        labelwest = new JLabel("Fahrenheit Temperature:");
        add(labelwest, BorderLayout.WEST);

        labeleast = new JLabel("Celsius Temperature");
        add(labeleast, BorderLayout.EAST);
//Create entry box
        centertextbox = new JTextField(8);
        add(centertextbox, BorderLayout.CENTER);
//Place button
        buttonbottom = new JButton("Convert");
        add(buttonbottom, BorderLayout.SOUTH);
//Handle a button press
        ButtonHandler handler = new ButtonHandler();
        buttonbottom.addActionListener(handler);
    }

    private class ButtonHandler implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent event) {
//when button is pressed get info from jtextfield and then calculate/display
            fahrenheit = Double.parseDouble(centertextbox.getText());
            celsius = (fahrenheit - 32);
            celsius = (celsius * (5.0 / 9.0));
            labeleast.setText(String.format("%.1f degrees Celsius", celsius));
        }

    }


}
