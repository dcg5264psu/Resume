/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package temp_converter;

/**
 *
 * @author Devin Gilmore
 */

import javax.swing.JFrame;

public class Temp_Test {

    public static void main(String[] args) {
        // TODO code application logic here

        Temp_Converter labelFrame = new Temp_Converter();
        labelFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        labelFrame.setSize(350,110);
        labelFrame.setVisible(true);
        
        
        
    }

}
