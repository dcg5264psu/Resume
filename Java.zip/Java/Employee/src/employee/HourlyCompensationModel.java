/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Devin Gilmore
 */
public class HourlyCompensationModel extends CompensationModel implements Compensation{
//Declare instance variables
    private double hoursWorked;
    private double payPerHour;
//Constructor
    public HourlyCompensationModel(double payPerHour, double hoursWorked ) {

        this.hoursWorked = hoursWorked;
        this.payPerHour = payPerHour;

    }
//Getters and setters
    public double getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(double hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public double getPayPerHour() {
        return payPerHour;
    }

    public void setPayPerHour(double payPerHour) {
        this.payPerHour = payPerHour;
    }
@Override
    public void raise(double percent) {

        setPayPerHour(getPayPerHour() + (getPayPerHour() * percent));
    }
    
    
@Override
    public double earnings() {
// If the employee worked overtime compensate for that.
        if (getHoursWorked() > 40) {

            return ((40 * getPayPerHour()) + ((getHoursWorked() - 40) * (getPayPerHour() * 1.5)));

        }
//If not return the wages
        return (getPayPerHour() * getHoursWorked());

    }
    
    //Show the information of an emplyee recieving this type of compensation
    @Override
    public String toString(){
    
        System.out.printf("%s%n%s%.2f%n%s%.2f%n%s%.2f%n","Hourly Compensation with:","Wage of:",getPayPerHour(),"Hours Worked of:",getHoursWorked(),"Earnings:",earnings());
    
    return(" ");
    }
}
