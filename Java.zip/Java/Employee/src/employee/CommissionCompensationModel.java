/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Devin Gilmore
 */
public class CommissionCompensationModel extends CompensationModel implements Compensation {

    //Declare variables
    private double grossSales; // gross weekly sales
    private double commissionRate; // commission percentage

    public CommissionCompensationModel(double grossSales, double commissionRate) {

        if (grossSales < 0.0) {
            throw new IllegalArgumentException("Gross sales must be >= 0.0");
        }

        // if commissionRate is invalid throw exception
        if (commissionRate <= 0.0 || commissionRate >= 1.0) {
            throw new IllegalArgumentException(
                    "Commission rate must be > 0.0 and < 1.0");
        }
        this.grossSales = grossSales;
        this.commissionRate = commissionRate;

    }
//getters and setters
    public double getGrossSales() {
        return grossSales;
    }

    public double getCommissionRate() {
        return commissionRate;
    }
    
    //Rasie the comission rate by the percent.
   @Override
    public void raise(double percent) {
    setCommissionRate(getCommissionRate() + (getCommissionRate() * percent));
    
    }

    public void setCommissionRate(double commissionRate) {
        this.commissionRate = commissionRate;
    }

    //Allow for the base earnings to be reached....Is there a better way to do this?
        public double getBaseEarnings() {
        return(0);
        }
        
        //Output thecommission
    @Override
    public double earnings() {

        return getGrossSales() * getCommissionRate() ;
    }
    
    
    //Show the information of an emplyee recieving this type of compensation
    @Override
    public String toString(){
    System.out.printf("%s%n%s%.2f%n%s%.3f%n%s%.2f%n","Commission Compensation with:","Gross Sales of:",getGrossSales(),
            "Commission Rate of:",getCommissionRate(),"Earnings:",earnings());
    
    return(" ");
    }
    
}