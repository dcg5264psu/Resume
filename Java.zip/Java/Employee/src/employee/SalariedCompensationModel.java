/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Devin Gilmore
 */
public class SalariedCompensationModel extends CompensationModel implements Compensation{

    private double weeklySalary;
//Constructor
    public SalariedCompensationModel(double weeklySalary) {
        this.weeklySalary = weeklySalary;

    }
//Getters and Setters
    public double getWeeklySalary() {
        return weeklySalary;
    }

    public void setWeeklySalary(double weeklySalary) {
        this.weeklySalary = weeklySalary;
    }
//Increase the oridional by the percent of the raise
    public void raise(double percent) {

        setWeeklySalary(getWeeklySalary() + (getWeeklySalary() * percent));

    }
    
    //Give back the weekly salary
@Override
    public double earnings() {

        return getWeeklySalary();
        
    }

    

    
    //Show the information of an emplyee recieving this type of compensation.
    @Override
    public String toString(){
    
        System.out.printf("%s%n%s%.2f%n%s%.2f%n","Salaried Compensation with:","Weekly Salary of:",getWeeklySalary(),"Earnings:",earnings());
        
    return(" ");
    }
}
