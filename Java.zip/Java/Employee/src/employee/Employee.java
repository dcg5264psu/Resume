/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Devin Gilmore
 */
public class Employee {
//Declare varibles 
    private final String firstName;
    private final String lastName;
    private final String socialSecurityNumber;
    private CompensationModel commissiontype;

    // five-argument constructor 
    public Employee(String firstName, String lastName,
            String socialSecurityNumber, CompensationModel commissiontype) {

        this.firstName = firstName;
        this.lastName = lastName;
        this.socialSecurityNumber = socialSecurityNumber;
        this.commissiontype = commissiontype;
    }
//Getters and Setters
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getSocialSecurityNumber() {
        return socialSecurityNumber;
    }

    public Object getCompensation() {
        return commissiontype;
    }

    public void setCompensation(CompensationModel type) {
        commissiontype = type;

    }
//Let the Commission model handle the earnings method
    public double earnings() {
        //point to Standard Commision model.
        return commissiontype.earnings();

        //base plus comission model
    }
    
    //Call the compensations raise method
    public void raise(double percent){
        
        
        commissiontype.raise(percent);
        
    }



//Print out the employee info 
@Override
    public String toString(){
        
    System.out.printf("%s%s%s%n%s%s%n",getFirstName()," ",getLastName(),"Social Security Number:",getSocialSecurityNumber());
    System.out.print(getCompensation());
    return(" ");
    }
        
        
       
      
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here

        // Create the two employees with their compensation models.
           // Print out the new information for the four employees.
                        // Create the four employees with their compensation models.
       
        CommissionCompensationModel commissionModel = new CommissionCompensationModel(2000.00, 0.04);
        BasePlusCommissionCompensationModel basePlusCommissionModel = new BasePlusCommissionCompensationModel(2000.00, 0.05, 600.00);
        SalariedCompensationModel salariedCompensationModel = new SalariedCompensationModel(2500.00);
        HourlyCompensationModel hourlyCommissionModel = new HourlyCompensationModel(10.00, 35.0);
       
        Employee employee1 = new Employee("John", "Smith", "111-11-1111", commissionModel);
        Employee employee2 = new Employee("Sue", "Jones", "222-22-2222", basePlusCommissionModel);
        Employee employee3 = new Employee("Jim", "Williams", "333-33-3333", salariedCompensationModel);
        Employee employee4 = new Employee("Nancy", "Johnson", "444-44-4444", hourlyCommissionModel);
       
        // Print the information about the four employees.
        System.out.println("The employee information initially.");
        System.out.printf("%s%n%s%n%s%n%s%n", employee1, employee2, employee3, employee4);
        System.out.printf("%s%s%s%s%s%8.2f%n%n", "Earnings for ", employee1.getFirstName(), " ", employee1.getLastName(), ": ", employee1.earnings());
       
        // Change the compensation model for the four employees.
       
        CommissionCompensationModel commissionModelNew = new CommissionCompensationModel(5000.00, 0.04);
        BasePlusCommissionCompensationModel basePlusCommissionModelNew = new BasePlusCommissionCompensationModel(4000.00, 0.05, 800.00);
        SalariedCompensationModel salariedCompensationModelNew = new SalariedCompensationModel(3500.00);
        HourlyCompensationModel hourlyCommissionModeNewl = new HourlyCompensationModel(10.00, 50);
       
        // Set the new compensation models for the employees.
        employee1.setCompensation(basePlusCommissionModelNew);
        employee2.setCompensation(commissionModelNew);
        employee3.setCompensation(hourlyCommissionModeNewl);
        employee4.setCompensation(salariedCompensationModelNew);
       
        // Print out the new information for the four employees.
        System.out.println("The employee information after changing compensation models.");
        System.out.printf("%s%n%s%n%s%n%s%n", employee1, employee2, employee3, employee4);
       
        // Declare an array of employees and assign the four employees to it.
        Employee[] employees = new Employee[4];
        employees[0] = employee1;
        employees[1] = employee2;
        employees[2] = employee3;
        employees[3] = employee4;
    
        // Loop thru the array giving each employee a 2% raise polymorphically;
        for (Employee employee : employees)
        {
            employee.raise(.02);
        }
       
        // Print out their new earnings.
        System.out.println("The employee information after raises of 2 percent.");
        System.out.printf("%s%n%s%n%s%n%s%n", employee1, employee2, employee3, employee4);}}