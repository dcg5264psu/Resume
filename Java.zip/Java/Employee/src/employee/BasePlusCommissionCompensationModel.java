/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Devin Gilmore
 */
public class BasePlusCommissionCompensationModel extends CommissionCompensationModel implements Compensation {
//Declare instance
    private double baseEarnings;
//Constructor
    public BasePlusCommissionCompensationModel(double grossSales, double commissionRate, double baseEarnings) {
        super(grossSales, commissionRate);
        this.baseEarnings = baseEarnings;

    }
//Increase the basse earnings by the percentage.
    @Override
    public void raise(double percent){
    
    setBaseEarnings(getBaseEarnings()+(getBaseEarnings() * percent));
    super.raise(percent);
    }
//Getters and setters
    public void setBaseEarnings(double baseEarnings) {
        this.baseEarnings = baseEarnings;
    }
    
    @Override
    public double getBaseEarnings() {
        return baseEarnings;
    }

    
//Overwrite the earnings method again

    @Override
    public double earnings() {

        return super.earnings() + baseEarnings;
    }
    
    //Show the information of an emplyee recieving this type of compensation
    @Override
    public String toString(){
    
        System.out.printf("%s%n%s%.2f%n%s%.3f%n%s%.2f%n%s%.2f%n","Base Plus Commission with:","Gross Sales of:",super.getGrossSales(),"Commission Rate of:",super.getCommissionRate(),"Base Salary of:",getBaseEarnings(),"Earnings of:",earnings());
        
    return(" ");
    }
}
