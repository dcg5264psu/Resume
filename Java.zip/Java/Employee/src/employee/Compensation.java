/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package employee;

/**
 *
 * @author Devin Gilmore
 */

//Make interface to apply to multiple classes to do with the compensation hiearchy
interface Compensation {
    
    
    
    
    public abstract double earnings();
    
    
    
    public abstract void raise(double percent);
    
}
